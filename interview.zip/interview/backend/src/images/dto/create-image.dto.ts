export class CreateImageDto {}
