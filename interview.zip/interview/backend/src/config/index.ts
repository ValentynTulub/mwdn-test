export { appConfig } from './app.config';
